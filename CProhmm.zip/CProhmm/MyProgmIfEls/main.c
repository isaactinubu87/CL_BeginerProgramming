#include <stdio.h>
#include <stdlib.h>

int main()
{
   int age;
   printf("Please enter the age ");
   scanf("%d", &age);

   if(age > 18){
    printf("The age is greater than 18");
   }
   else if (age == 18){
    printf("The age is equal to 18");
   }
   else{
   printf("The age is not greater than 18");
   }
}
