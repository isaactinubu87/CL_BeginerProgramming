#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i =0;
   do {
        printf("Value of i = %d \n", i);
        i ++;

   }while(i <= 10);
   // Do while execute before once before considering the condition
   // while loop consider the condition
}
