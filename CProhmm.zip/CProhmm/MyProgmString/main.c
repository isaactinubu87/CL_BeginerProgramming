#include <stdio.h>
#include <stdlib.h>
#include <string.h> ///to use string methods

int main()
{
    /*
    ///to declare a string in C
    /// 1. definite size array
   char my_string[6] = {'H','e','1','1','o','\0'}; /// \0 mean non terminated

   ///2. non definite size array

   char my_other_string[] = "Hello";

   printf("my string value = %s \n", my_string);
   printf("my other string value = %s \n", my_other_string);
   return 0;
   */
   ///strcpy: this function enables us to copy one function to another

   char string1[12] = "Hello";
   char string2[12] = " World";
   char string3[12];

   strcpy(string3, string1); ///To copy string1 to string3, strcpy(destination, source)
   strcat(string1, string2); ///concatenation i.e add string2 to string1
   int length_string1 = strlen(string1); ///lenght of the string

   printf("strcpy = %s \n ", string3);
   printf("strcat = %s \n ", string1);
   printf("strlen = %d \n ", length_string1);
   return 0;


}
