#include <stdio.h>
#include <stdlib.h>
#include <string.h>


///A group of identities to group together to make logical variable
struct student {

    int ID;
    char name[20];
    float percentage;

};

int main()
{
    struct student record1; ///record1 is the variable, hence student is data type

    record1.ID = 1;
    strcpy(record1.name, "John");
    record1.percentage = 70.20;

    printf("ID= %d \n Name = %s \n  Percent = %f \n",
           record1.ID, record1.name, record1.percentage);

    struct student record2;

    record2.ID = 2;
    strcpy(record2.name, "Dayo");
    record2.percentage = 90;

    printf("ID= %d \n Name = %s \n  Percent = %f \n",
           record2.ID, record2.name, record2.percentage);


    return 0;

}
