#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union myUnion {

    int myInt;
    char myChar;
};

int main()
{
    union myUnion uni;
    uni.myInt = 4;
    uni.myChar = 9;

    printf("%i \n", uni.myInt);


    return 0;
}
