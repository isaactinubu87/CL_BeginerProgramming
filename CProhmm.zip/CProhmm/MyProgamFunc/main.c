#include <stdio.h>
#include <stdlib.h>

void MyFunctionName(){

    printf("sum = %d \n", 10+52);
    printf("We are inside a function \n");
}

int main()
{
    MyFunctionName();
     MyFunctionName();
      MyFunctionName();
       MyFunctionName();

    //Use to perform a particular task
    //can be called in another function

}
