#include <stdio.h>
#include <stdlib.h>

int main()
{
   //int i = 0;

   for (int i = 0; i < 10; i++){

    printf("the value of i = %d", i);
   }


}
