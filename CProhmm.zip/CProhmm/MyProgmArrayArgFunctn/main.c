#include <stdio.h>
#include <stdlib.h>

int ArraySum(int MyArray[], int size)
{
    int sum = 0;
    for (int i= 0; i<size; i++)
    {
        sum = sum + MyArray[i];

    }
     return sum;
}

///unsized array

int main()
{
    ///Adding arrays

    int MyNumberArray [6] = {20,30,60,50,55,33,199,100};
    int sum_of_array = ArraySum(MyNumberArray, 8);

    printf("Array Sum = %d", sum_of_array);
}
