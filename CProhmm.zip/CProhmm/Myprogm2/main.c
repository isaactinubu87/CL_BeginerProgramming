#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("Hello Isaac\n");
    printf("%f", 32.5); // float
    printf("\n the number is = %d ", 34);
    printf("%d %d %d \n", 56,45, 89);
    printf("%c \n", 'a'); // char
    printf("\n %s", "Hello World! \n"); ///string
    printf("%lf \n", 64564.8765); ///large float
    printf("%x \n", 16); ///Hex
    printf("%ld \n", 32786528972);///large integer

    /*This program is
    printing the total number of students
    in the class
    for the government*/

    puts("This is my C programming");
    return 0;
}
