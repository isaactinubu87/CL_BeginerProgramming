#include <stdio.h>
#include <stdlib.h>

//Global variable
int global_v = 25;

void NumberPrint(){
    ///local variable
    int Num_local = 30;
    printf("Global + 50 = %d\n", global_v + 50);

}

int main()
{
    ///local variable
    int global_v =24;
    printf("Local = %d\n", local_v);
    printf("Global = %d\n", global_v);
    NumberPrint();
}
//You cannot use a local variable in another function: Calling it gives error
