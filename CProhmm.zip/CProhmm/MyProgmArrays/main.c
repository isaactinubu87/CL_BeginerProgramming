#include <stdio.h>
#include <stdlib.h>

int main()
{
    int MyNumberArray [6] = {20,30,60,78,89,95};
/*
    int accessArray = MyNumberArray[1];
    printf("value = %d\n", accessArray);

    char charArray[4] = {'a','b','c','d'};
    */
    MyNumberArray[1] = 45;

    for (int i = 0; i < 6; i ++){

        printf("element[%d] = %d \n", i, MyNumberArray[i]);
    }

}
