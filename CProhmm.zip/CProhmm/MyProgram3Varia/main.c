#include <stdio.h>
#include <stdlib.h>

int main()

{
    float modulus;
    int age = 34;

    int a = 12;
    int b = 56;

    modulus = b % a;
    printf("Product = %f ", modulus);

    printf("\n His age is: %d ", age);
    return 0;
}
