#include <stdio.h>
#include <stdlib.h>
/*
void Sum(int a, int b){
    int sum = a + b;
    printf("sum is = %d \n", sum);

}
*/

int Product(int a, int b){

    return a * b;

}
int main()
{
    /*
  int x, y;
  printf("Please enter two numbers\n");
  printf("number1 \n");
  scanf("%d", &x);

  printf("number2 \n");
  scanf("%d", &y);

  //Sum(x,y);

  int prod;
  prod = Product(x,y);

  printf("Product = %d", prod);

  */
  printf("result = %d", Product(5,5)+ 10);


}
