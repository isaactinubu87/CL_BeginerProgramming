#include <stdio.h>
#include <stdlib.h>

int main()
{
   int marks; //= 61;
   printf("Please enter the marks: ");
   scanf("%f", &marks);

   switch (marks){

   case 95:
   case 92:
   case 90:
    printf("Excellent");
    break;
   case 75:
   case 65:
   case 61:
    printf("Very Good");
    break;
   case 60:
    printf("Good");
    break;
   case 40:
    printf("Okay");
    break;
   default:
    printf("Grade unavailable");

   }
}
