#include <stdio.h>
#include <stdlib.h>
#include <string.h>


///A group of identities to group together to make logical variable
struct student {

    int ID;
    char name[20];
    float percentage;

}record;  ///variable name of the structure

int main()
{
   ///record1 is the variable, hence student is data type

    record.ID = 1;
    strcpy(record.name, "John");
    record.percentage = 70.20;

    printf("ID= %d \n Name = %s \n  Percent = %f \n",
           record.ID, record.name, record.percentage);
    return 0;
}
