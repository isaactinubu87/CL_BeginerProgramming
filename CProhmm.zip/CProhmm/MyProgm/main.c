#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("Hello Isaac")
    printf("%f", 32.5)
    return 0;
}

