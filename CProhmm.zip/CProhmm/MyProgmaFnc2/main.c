#include <stdio.h>
#include <stdlib.h>

void MyFunctionName();

int main()
{
   MyFunctionName();
}
void MyFunctionName(){

    printf("sum = %d \n", 10+52);
    printf("We are inside a function \n");
}
