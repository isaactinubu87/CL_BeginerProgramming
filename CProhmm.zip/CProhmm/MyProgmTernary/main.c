#include <stdio.h>
#include <stdlib.h>

int main()
{
   ///Ternary conditional operator

   int a = 40, b = 35;
   ///if else comparison might be long
   int c;
   c = (a>b)? b:a; //if a gt b, return b else a
   printf("ans = %d", c);
}
