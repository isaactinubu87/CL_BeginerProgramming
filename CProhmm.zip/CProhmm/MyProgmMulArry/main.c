#include <stdio.h>
#include <stdlib.h>

int main()
{
    int MyNumberArray [2] [3] = {
        /// two rows
        /// three column

        {1,3,5}, ///row 0
        {2,4,6}, ///row 1


    };
    ///for multi array use for loop

    for (int i = 0; i < 2; i++){  ///row

        for(int j = 0; j < 3; j++){
            printf("MyNumberArray[%d][%d]= %d\n", i,j, MyNumberArray[i][j]);
        }
    }
}
