#include <stdio.h>
#include <stdlib.h>

/*
void getValue(int *my_pointer)
{
    *my_pointer = 10000; /// &get_the_value = 10000
    return;
}
int main()
{
    int get_the_value;
    getValue(&get_the_value);

    printf("The value of get_the_value = %d", get_the_value);

}
*/

int getSum(int *array_val, int size)
{
    int sum = 0;
    for(int i = 0; i < size; i++)
    {
        sum +=array_val[i];
    }
    return sum;
}

int main()
{
    int my_array[7] = {20,50,20,70,60,80,90};
    int mySum = getSum(my_array,7);

    printf("The value of my sum = %d", mySum);
}
